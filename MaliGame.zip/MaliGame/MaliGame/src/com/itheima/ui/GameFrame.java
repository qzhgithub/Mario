package com.itheima.ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.itheima.mario.Mario;
import com.itheima.role.*;
import com.itheima.util.Map;
import com.itheima.util.MusicUtil;
/**
 main windows interface: show mario

 */
public class GameFrame extends JFrame{
	public Mario mario;
	public Enemy pipe ,cion , brick;
	//background picture
	public BackgroundImage bg ;
	//declare a container to collect enemy object
	public ArrayList<Enemy> eneryList = new ArrayList<Enemy>();
	//declare a container to collect bullet
	public ArrayList<Boom> boomList = new ArrayList<Boom>();
	//speed of bullet
	public int bspeed=0;

	//rules for drawing: 1 is brick, 2 is coin, 3 is pipe
	public int[][] map = null;
	{
		Map mp = new Map();
		map = mp.readMap();
	}

	//initial mario and background picture
	public GameFrame() throws Exception {
		//initial  information of  windows
		// this represent current object in main interface
		this.setSize(800,450);
		this.setTitle("mario");
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);

		// create object mario
		mario = new Mario(this);

		// create background
		bg = new BackgroundImage();

		// read data and draw map
		for (int i = 0; i < map.length; i++) {
			for (int j = 0; j < map[0].length; j++) {
				//read 1 then draw brick
				if(map[i][j]==1){
					brick = new Brick(j*30,i*30,30,30,new ImageIcon("image/brick.png").getImage());
					eneryList.add(brick);
				}
				//read 2 then draw coin
				if(map[i][j]==2){
					cion = new Coin(j*30,i*30,30,30,new ImageIcon("image/coin_brick.png").getImage());
					eneryList.add(cion);
				}
				//read 3 then draw pipe
				if(map[i][j]==3){
					pipe = new Pipe(j*30,i*30,60,120,new ImageIcon("image/pipe.png").getImage());
					eneryList.add(pipe);
				}

			}
		}

		mario.start();

		//open a thread to control windows redraw
		new Thread(){
			public void run(){
				while(true){
					//redraw window
					repaint(); // automatic trigger paint method
					//check bullet whether out of bounds
					//checkBoom();
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();


		//set BGM
//		new Thread(new Runnable() {
//			@Override
//			public void run() {
//				MusicUtil.playBackground();
//			}
//		}).start();
	}

	@Override
	public void paint(Graphics g) {
		BufferedImage bi =(BufferedImage)this.createImage(this.getSize().width,this.getSize().height);
		Graphics big = bi.getGraphics();
		big.drawImage(bg.img, bg.x, bg.y, null);

		//start to draw enemy on the interface
		for (int i = 0; i < eneryList.size(); i++) {
			Enemy e = eneryList.get(i);
			big.drawImage(e.img, e.x, e.y, e.width, e.height,null);
		}

		for (int i = 0; i < boomList.size(); i++) {
			Boom b =boomList.get(i);
			Color c =big.getColor();
			big.setColor(Color.red);
			big.fillOval(b.x+=b.speed, b.y, b.width, b.width);
			big.setColor(c);
		}

		//draw mario
		big.drawImage(mario.img, mario.x, mario.y, mario.width, mario.height,null);
		g.drawImage(bi,0,0,null);

	}

	//check bullet whether out of bounds, if out of bounds then remove it
	public void checkBoom(){
		for (int i = 0; i < boomList.size(); i++) {
			Boom b = boomList.get(i);
			if(b.x<0 || b.x>800){
				boomList.remove(i);
			}
		}
	}

}
