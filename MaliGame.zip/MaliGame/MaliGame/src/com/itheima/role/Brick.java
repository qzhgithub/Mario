package com.itheima.role;
import java.awt.Image;
//brick class
public class Brick extends Enemy {
    public Brick(int x, int y, int width, int height, Image img) {
        super(x, y, width, height, img);
    }
}
