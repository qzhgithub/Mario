package com.itheima.role;
import java.awt.Image;
//pipe class
public class Pipe extends Enemy {
	public Pipe(int x, int y, int width, int height, Image img) {
		super(x, y, width, height, img);
	}
}
