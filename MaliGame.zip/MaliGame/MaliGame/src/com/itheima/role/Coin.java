package com.itheima.role;

import java.awt.Image;

//coin class
public class Coin extends Enemy {
	public Coin(int x, int y, int width, int height, Image img) {
		super(x, y, width, height, img);
	}
}
