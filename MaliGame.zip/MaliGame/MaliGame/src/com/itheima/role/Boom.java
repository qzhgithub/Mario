package com.itheima.role;
/**
  bullet
 */
public class Boom {
	//position, size and speed of  bullet
	public int x,y;
	public int width;
	public int speed=1;
	
	public Boom(int x, int y, int width) {
		super();
		this.x = x;
		this.y = y;
		this.width = width;
	}

}
