import com.itheima.ui.GameFrame;
import com.itheima.util.KeyListener;
/**
  program start class
 */
public class Run {
	//entrance of main program
	public static void main(String[] args) throws Exception {
		GameFrame gf = new GameFrame();
		// create listener object
		KeyListener kl = new KeyListener(gf);
		// add keyboard listener
		gf.addKeyListener(kl);
	}
}
